## 🏠 Home

This is a non-collaborative project developed by me for the Web Interface Development academic work in Computer Science at PUC Minas - 2021/2. The website developed aims to mirror the student's personal information and their future projects and experiences.


## 📚 Class

PUC Minas/Coração Eucarístico - Computer Science - 2021/2
